package com.raival.compose.file.explorer.screen.main

import android.content.Context
import com.raival.compose.file.explorer.App.Companion.globalClass
import com.raival.compose.file.explorer.common.isNot
import com.raival.compose.file.explorer.common.toJson
import com.raival.compose.file.explorer.screen.main.startup.StartupTab
import com.raival.compose.file.explorer.screen.main.startup.StartupTabType
import com.raival.compose.file.explorer.screen.main.startup.StartupTabs
import com.raival.compose.file.explorer.screen.main.tab.Tab
import com.raival.compose.file.explorer.screen.main.tab.apps.AppsTab
import com.raival.compose.file.explorer.screen.main.tab.files.FilesTab
import com.raival.compose.file.explorer.screen.main.tab.files.holder.LocalFileHolder
import com.raival.compose.file.explorer.screen.main.tab.files.provider.StorageProvider
import com.raival.compose.file.explorer.screen.main.tab.home.HomeTab
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

class MainActivityManager {
    val managerScope = CoroutineScope(Dispatchers.IO)
    private val _state = MutableStateFlow(MainActivityState())
    val state = _state.asStateFlow()


    /**\
     * Loads available storage devices (Internal Storage, SD cards, etc)
     */
    fun setup() {
        managerScope.launch {
            _state.update {
                it.copy(
                    storageDevices = StorageProvider.getStorageDevices(globalClass)
                )
            }
        }
    }

    /**
     * Removes all tabs except the one at the given index.
     *
     * If the tab at the given index is not already selected, it will be selected first.
     * Then, all other tabs will be removed.
     *
     * @param tabIndex The index of the tab to keep.
     */
    fun removeOtherTabs(tabIndex: Int) {
        // For now, you can only remove tabs other than the selected tab
        if (tabIndex isNot _state.value.selectedTabIndex) return

        val tabToKeep = _state.value.tabs[tabIndex]
        val tabsToRemove = _state.value.tabs.filter { it != tabToKeep }

        // Call onTabRemoved on tabs being removed BEFORE state update
        tabsToRemove.forEach { it.onTabRemoved() }

        // Update the state
        _state.update {
            it.copy(
                tabs = listOf(tabToKeep),
                selectedTabIndex = 0
            )
        }
    }

    fun removeTabAt(index: Int) {
        // There must be at least one tab
        if (_state.value.tabs.size <= 1) return

        val tabToRemove = _state.value.tabs[index]
        val currentSelectedIndex = _state.value.selectedTabIndex

        // Call callbacks on the tab to be removed BEFORE state update
        if (currentSelectedIndex == index) {
            tabToRemove.onTabStopped()
        }
        tabToRemove.onTabRemoved()

        // Calculate new selected tab index
        val newSelectedTabIndex = if (index < currentSelectedIndex) {
            currentSelectedIndex - 1
        } else if (index > currentSelectedIndex) {
            currentSelectedIndex
        } else {
            // Removing the selected tab itself - choose the previous tab if available, otherwise the next one
            max(0, index - 1)
        }

        // Update the state
        _state.update {
            it.copy(
                tabs = _state.value.tabs.filterIndexed { i, _ ->
                    i isNot index
                },
                selectedTabIndex = newSelectedTabIndex
            )
        }

        // Call callbacks on the new selected tab AFTER state update (if it's different from before)
        if (index == currentSelectedIndex) {
            val newSelectedTab = _state.value.tabs[newSelectedTabIndex]
            if (newSelectedTab.isCreated) {
                newSelectedTab.onTabResumed()
            } else {
                newSelectedTab.onTabStarted()
            }
        }
    }

    fun addTabAndSelect(tab: Tab, index: Int = -1) {
        val currentActiveTab = getActiveTab()

        // Stop the active tab BEFORE state update
        currentActiveTab?.onTabStopped()

        // Validate the index
        val validatedIndex = if (index isNot -1) {
            max(0, min(index, _state.value.tabs.lastIndex + 1))
        } else {
            _state.value.tabs.lastIndex + 1
        }

        // Update the state
        _state.update {
            it.copy(
                tabs = _state.value.tabs + tab,
                selectedTabIndex = validatedIndex
            )
        }

        // Start the new tab AFTER state update
        if (tab.isCreated) {
            tab.onTabResumed()
        } else {
            tab.onTabStarted()
        }
    }

    fun selectTabAt(index: Int, skipTabRefresh: Boolean = false) {
        // Validate the index
        val validatedIndex = if (index isNot -1) {
            max(0, min(index, _state.value.tabs.lastIndex))
        } else {
            _state.value.tabs.lastIndex
        }

        val currentSelectedIndex = _state.value.selectedTabIndex
        val currentActiveTab = getActiveTab()

        // If the tab is already selected, resume that tab (kind of refreshing the tab)
        if (validatedIndex == currentSelectedIndex) {
            if (!skipTabRefresh) {
                currentActiveTab?.onTabResumed()
            }
        } else {
            // Stop the active tab BEFORE state update
            currentActiveTab?.onTabStopped()

            // Update the state
            _state.update {
                it.copy(selectedTabIndex = validatedIndex)
            }

            // Start the new tab AFTER state update
            val newSelectedTab = _state.value.tabs[validatedIndex]
            if (newSelectedTab.isCreated) {
                newSelectedTab.onTabResumed()
            } else {
                newSelectedTab.onTabStarted()
            }
        }
    }

    fun replaceCurrentTabWith(tab: Tab, keepCurrentTabAsParent: Boolean = false) {
        val currentActiveTab = getActiveTab()

        // Stop and remove the active tab BEFORE state update
        currentActiveTab?.apply {
            onTabStopped()
            if (!keepCurrentTabAsParent) onTabRemoved()
        }

        if (keepCurrentTabAsParent) {
            tab.parentTab = currentActiveTab
        }

        // Update the state
        _state.update {
            it.copy(
                tabs = _state.value.tabs.mapIndexed { index, oldTab ->
                    if (index == _state.value.selectedTabIndex) tab else oldTab
                }
            )
        }

        // Start the new tab AFTER state update
        if (tab.isCreated) {
            tab.onTabResumed()
        } else {
            tab.onTabStarted()
        }
    }

    fun jumpToFile(file: LocalFileHolder, context: Context) {
        openFile(file, context)
    }

    private fun openFile(file: LocalFileHolder, context: Context) {
        if (file.exists()) {
            addTabAndSelect(FilesTab(file, context))
        }
    }

    fun resumeActiveTab() {
        getActiveTab()?.onTabResumed()
    }

    fun onResume() {
        resumeActiveTab()
    }

    fun onStop() {
        getActiveTab()?.onTabStopped()
    }

    fun getActiveTab(): Tab? {
        return if (_state.value.tabs.isNotEmpty()) {
            _state.value.tabs[_state.value.selectedTabIndex]
        } else {
            null
        }
    }

    /**
     * Checks if the app can exit.
     *
     * This function checks the following conditions in order:
     * 1. If the active tab handles the back press, the app cannot exit.
     * 2. If the active tab is not the home tab and the "skip home when tab closed" setting is disabled,
     *    the active tab is replaced with the home tab and the app cannot exit.
     * 3. If there is more than one tab and the selected tab is not the first tab,
     *    the active tab is removed and the app cannot exit.
     * 4. If there is only one tab and there are unsaved files in the text editor,
     *    a dialog is shown to save the files and the app cannot exit.
     *
     * If none of the above conditions are met, the app can exit.
     *
     * @return True if the app can exit, false otherwise.
     */
    fun canExit(): Boolean {
        val tabs = _state.value.tabs
        val selectedTabIndex = _state.value.selectedTabIndex

        if (tabs.isEmpty()) {
            return true
        }

        // Handle tabs's onBackPress
        if (getActiveTab()!!.onBackPressed()) {
            return false
        }

        // Replace with parent tab if exists
        if (getActiveTab()!!.parentTab != null) {
            replaceCurrentTabWith(getActiveTab()!!.parentTab!!, false)
            return false
        }

        // Replace the active tab with the home tab (if turned on in settings)
        if (getActiveTab() !is HomeTab && !globalClass.preferencesManager.skipHomeWhenTabClosed) {
            replaceCurrentTabWith(HomeTab())
            return false
        }

        // Remove the active tab
        if (tabs.size > 1 && selectedTabIndex isNot 0 && globalClass.preferencesManager.closeTabOnBackPress) {
            removeTabAt(selectedTabIndex)
            return false
        }

        // Check TextEditor files
        if (tabs.size == 1 && !allTextEditorFileInstancesSaved()) {
            _state.update {
                it.copy(
                    showSaveEditorFilesDialog = true
                )
            }
            return false
        }

        return true
    }

    private fun allTextEditorFileInstancesSaved(): Boolean {
        globalClass.textEditorManager.fileInstanceList.forEach {
            if (it.requireSave) return false
        }
        return true
    }

    fun ignoreTextEditorFiles() {
        globalClass.textEditorManager.fileInstanceList.clear()
    }

    fun saveTextEditorFiles(onFinish: () -> Unit) {
        _state.update {
            it.copy(
                isSavingFiles = true
            )
        }

        managerScope.launch {
            globalClass.textEditorManager.fileInstanceList.apply {
                forEach {
                    if (it.requireSave) {
                        it.file.writeText(it.content.toString())
                    }
                }
                clear()
            }

            _state.update {
                it.copy(
                    isSavingFiles = false
                )
            }

            onFinish()
        }
    }

    fun saveSession() {
        val startupTabs = arrayListOf<StartupTab>()
        _state.value.tabs.forEach { tab ->
            when (tab) {
                is FilesTab -> {
                    startupTabs.add(
                        StartupTab(
                            type = StartupTabType.FILES,
                            extra = tab.activeFolder.uniquePath
                        )
                    )
                }

                is AppsTab -> {
                    startupTabs.add(
                        StartupTab(
                            type = StartupTabType.APPS
                        )
                    )
                }

                else -> {
                    startupTabs.add(
                        StartupTab(
                            type = StartupTabType.HOME
                        )
                    )
                }
            }
        }
        globalClass.preferencesManager.lastSessionTabs = StartupTabs(startupTabs).toJson()
    }

    fun loadStartupTabs() {
        managerScope.launch {
            // Always start in the Downloads folder (ignores saved session and startup tabs)
            val downloads = android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                .apply { if (!exists()) mkdirs() }

            val tabs = arrayListOf<Tab>(FilesTab(LocalFileHolder(downloads)))
            val index = 0

            // Update the state first
            _state.update {
                it.copy(
                    tabs = tabs,
                    selectedTabIndex = index
                )
            }

            // Call callbacks on tabs AFTER state update
            tabs.forEachIndexed { tabIndex, tab ->
                if (tabIndex == index) {
                    // This is the selected tab
                    if (tab.isCreated) {
                        tab.onTabResumed()
                    } else {
                        tab.onTabStarted()
                    }
                }
            }
        }
    }

    fun toggleJumpToPathDialog(show: Boolean) {
        _state.update {
            it.copy(
                showJumpToPathDialog = show
            )
        }
    }

    fun toggleSaveEditorFilesDialog(show: Boolean) {
        _state.update {
            it.copy(
                showSaveEditorFilesDialog = show
            )
        }
    }

    fun toggleStartupTabsDialog(show: Boolean) {
        _state.update {
            it.copy(
                showStartupTabsDialog = show
            )
        }
    }

    fun reorderTabs(from: Int, to: Int) {
        val activeTab = getActiveTab()
        val reordered = _state.value.tabs.toMutableList().apply {
            add(to, removeAt(from))
        }
        _state.update {
            it.copy(
                tabs = reordered,
                selectedTabIndex = reordered.indexOf(activeTab).coerceAtLeast(0)
            )
        }
    }

    fun updateHomeToolbar(title: String, subtitle: String) {
        _state.update {
            it.copy(title = title, subtitle = subtitle)
        }
    }
}
package com.raival.compose.file.explorer.common

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Context.logsDataStore: DataStore<Preferences> by preferencesDataStore(name = "logs")

data class LogHolder(
    val message: String,
    val timestamp: String,
    val id: String = UUID.randomUUID().toString()
)

class FileExplorerLogger(
    private val context: Context,
    private val scope: CoroutineScope
) {

    companion object {
        private val ERRORS_KEY = stringPreferencesKey("error_logs")
        private val WARNINGS_KEY = stringPreferencesKey("warning_logs")
        private val INFOS_KEY = stringPreferencesKey("info_logs")
        private const val MAX_ERRORS = 5
        private const val MAX_WARNINGS = 10
        private const val MAX_INFOS = 30
    }

    private val gson = Gson()
    private val logListType = object : TypeToken<List<LogHolder>>() {}.type
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    // ERROR LOGGING FUNCTIONS
    /**
     * Log a string error message
     */
    fun logError(message: String) {
        val errorLog = LogHolder(
            message = message,
            timestamp = dateFormat.format(Date())
        )
        scope.launch {
            saveError(errorLog)
        }
    }

    /**
     * Log an exception
     */
    fun logError(exception: Throwable) {
        val errorLog = LogHolder(
            message = exception.stackTraceToString(),
            timestamp = dateFormat.format(Date())
        )
        scope.launch {
            saveError(errorLog)
        }
    }

    /**
     * Save error to DataStore, maintaining only the 5 most recent
     */
    private suspend fun saveError(newError: LogHolder) {
        context.logsDataStore.edit { preferences ->
            val currentErrorsJson = preferences[ERRORS_KEY] ?: "[]"
            val currentErrors = try {
                gson.fromJson<List<LogHolder>>(currentErrorsJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }

            // Add new error at the beginning and keep only the most recent
            val updatedErrors = (listOf(newError) + currentErrors).take(MAX_ERRORS)

            preferences[ERRORS_KEY] = gson.toJson(updatedErrors)
        }
    }

    /**
     * Get all stored errors as a Flow
     */
    fun getErrors(): Flow<List<LogHolder>> {
        return context.logsDataStore.data.map { preferences ->
            val errorsJson = preferences[ERRORS_KEY] ?: "[]"
            try {
                gson.fromJson<List<LogHolder>>(errorsJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /**
     * Clear all stored errors
     */
    suspend fun clearErrors() {
        context.logsDataStore.edit { preferences ->
            preferences.remove(ERRORS_KEY)
        }
    }

    // WARNING LOGGING FUNCTIONS
    /**
     * Log a string warning message
     */
    fun logWarning(message: String) {
        val warningLog = LogHolder(
            message = message,
            timestamp = dateFormat.format(Date())
        )
        scope.launch {
            saveWarning(warningLog)
        }
    }

    /**
     * Log an exception as warning
     */
    fun logWarning(exception: Throwable) {
        val warningLog = LogHolder(
            message = exception.printFullStackTrace(),
            timestamp = dateFormat.format(Date())
        )
        scope.launch {
            saveWarning(warningLog)
        }
    }

    /**
     * Save warning to DataStore, maintaining only the 10 most recent
     */
    private suspend fun saveWarning(newWarning: LogHolder) {
        context.logsDataStore.edit { preferences ->
            val currentWarningsJson = preferences[WARNINGS_KEY] ?: "[]"
            val currentWarnings = try {
                gson.fromJson<List<LogHolder>>(currentWarningsJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }

            // Add new warning at the beginning and keep only the most recent 10
            val updatedWarnings =
                (listOf(newWarning) + currentWarnings).take(MAX_WARNINGS)

            preferences[WARNINGS_KEY] = gson.toJson(updatedWarnings)
        }
    }

    /**
     * Get all stored warnings as a Flow
     */
    fun getWarnings(): Flow<List<LogHolder>> {
        return context.logsDataStore.data.map { preferences ->
            val warningsJson = preferences[WARNINGS_KEY] ?: "[]"
            try {
                gson.fromJson<List<LogHolder>>(warningsJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /**
     * Clear all stored warnings
     */
    suspend fun clearWarnings() {
        context.logsDataStore.edit { preferences ->
            preferences.remove(WARNINGS_KEY)
        }
    }

    // INFO LOGGING FUNCTIONS
    /**
     * Log a string info message
     */
    fun logInfo(message: String) {
        val infoLog = LogHolder(
            message = message,
            timestamp = dateFormat.format(Date())
        )
        scope.launch {
            saveInfo(infoLog)
        }
    }

    /**
     * Save info to DataStore, maintaining only the 30 most recent
     */
    private suspend fun saveInfo(newInfo: LogHolder) {
        context.logsDataStore.edit { preferences ->
            val currentInfosJson = preferences[INFOS_KEY] ?: "[]"
            val currentInfos = try {
                gson.fromJson<List<LogHolder>>(currentInfosJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }

            // Add new info at the beginning and keep only the most recent 30
            val updatedInfos = (listOf(newInfo) + currentInfos).take(MAX_INFOS)

            preferences[INFOS_KEY] = gson.toJson(updatedInfos)
        }
    }

    /**
     * Get all stored infos as a Flow
     */
    fun getInfos(): Flow<List<LogHolder>> {
        return context.logsDataStore.data.map { preferences ->
            val infosJson = preferences[INFOS_KEY] ?: "[]"
            try {
                gson.fromJson<List<LogHolder>>(infosJson, logListType) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /**
     * Clear all stored infos
     */
    suspend fun clearInfos() {
        context.logsDataStore.edit { preferences ->
            preferences.remove(INFOS_KEY)
        }
    }

    // UTILITY FUNCTIONS
    /**
     * Clear all logs (errors, warnings, and infos)
     */
    suspend fun clearAllLogs() {
        context.logsDataStore.edit { preferences ->
            preferences.remove(ERRORS_KEY)
            preferences.remove(WARNINGS_KEY)
            preferences.remove(INFOS_KEY)
        }
    }
}